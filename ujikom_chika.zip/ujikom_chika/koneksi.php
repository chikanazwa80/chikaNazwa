 <?php
$koneksi=mysqli_connect('localhost','root','','chika_praukk_rpl2');
//$koneksi=mysqli_connect("localhost","root","","ujikom");
?> 



