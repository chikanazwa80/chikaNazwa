<?php
session_star();
unset($_SESSION['nama']);
session_destroy();
header('location:index.php');
?>