<?php
require '../koneksi.php';
$id=$_GET['id'];

$sql=mysqli_query($koneksi, "DELETE FROM petugas WHERE id_petugas='$id' ");

    if ($sql){
        header("location:admin.php?url=lihat_petugas");
} else{
    
}
?>